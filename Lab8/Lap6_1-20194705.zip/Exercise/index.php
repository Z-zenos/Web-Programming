<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Business Service</title>
</head>
<body>
  <h1>Business Service</h1>

  <p><a href="category-administration.php">Category Management</a></p>
  <p><a href="business-registration.php">Register new Business</a></p>
  <p><a href="business-listing.php">Show Categories with corresponding Business</a></p>
</body>
</html>